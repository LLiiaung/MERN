import React from 'react'

export default function Footer() {
  return (
    <div style={{backgroundColor:'blue'}}>
      <p>Designed and Developed by</p>
      <p>Leon</p>
    </div>
  )
}
